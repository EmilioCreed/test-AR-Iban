Photovoltaic Sunshade


Units of measurement

	This model was created using metric units and 1 unit = 1 meter.  The scale will have to be adjusted for other units of measure.
	1 meter = 100 cm = 3.28 feet = 39.37 inches




Textures and materials

	Object				Filename				Pixel size		Type of map

	solar panels			solar panel texture 001.png		4096x4096		Texture
	base				screen texture 001.png			2048x2048		Texture




	All materials used raytraced reflections for the preview images.  The amount of reflection will have to be adjusted depending on the rendering software used and lighting setup for the scene.


	Raytrace reflections for each material

	gray metal: 5%
	chrome: 70%
	black screen: 5%
	blue emission: 10%	Emission material to create glowing effect.
	blue solar panels:  	Glass material with IOR=1.4



Vertices and faces


	Vertices: 5382
	Polygons: 5190




